
#include "../include/ambest.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <numeric>
#include <vector>
AmBest::AmBest(int populationSize, double crossoverProb, double mutationProb,
               int tournamentSize)
    : Am(populationSize, crossoverProb, mutationProb) {}

void AmBest::applyLocalSearch(std::vector<tSolution<double>> &poblation,
                             std::vector<double> &fitnessPoblation,
                             double &bestFitness,
                             tSolution<double> &bestSolution,
                             Problem<double> &problem, int maxevals) {
  int nBest = std::ceil(this->populationSize * 0.1);
  std::vector<int> indices(this->populationSize);
  std::iota(indices.begin(), indices.end(), 0);

  /// busco los indices del 10%  mejores soluciones
  std::nth_element(indices.begin(), indices.begin() + nBest, indices.end(),
                   [&fitnessPoblation](int i, int j) {
                     return fitnessPoblation[i] > fitnessPoblation[j];
                   });
  indices.resize(nBest);
  for (int i : indices) {
    if ( evals+ 100 > maxevals) {
      break;
    } else {
      evals += 100;
    }
    ResultMH<double> result = localSearch(problem, 500, poblation[i]);
		
    if (result.fitness > fitnessPoblation[i]) {
      fitnessPoblation[i] = result.fitness;
      poblation[i] = result.solution;
    }
    if (result.fitness > bestFitness) {
      bestFitness = result.fitness;
      bestSolution = result.solution;
    }
  }
}
